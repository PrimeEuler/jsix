# jsix
JSIX is a UNIX like operating system with a kernel and shell written in javascript
